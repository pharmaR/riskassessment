# waterfalls 1.0.0

* Added a `NEWS.md` file to track changes to the package.
* `rect_border` now vectorized thanks to a PR by robert-koetsier.
* Package stable enough for v1.0.0
