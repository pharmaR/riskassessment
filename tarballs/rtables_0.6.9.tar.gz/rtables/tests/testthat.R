library(testthat)
test_check("rtables", reporter = "check")
