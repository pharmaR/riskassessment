
# start the watchdog eagerly, so that our tests around potentially
# modified connections don't pick up on the new process
renv_watchdog_check()
