library(testthat)
library(metatools)

test_check("metatools")
