#' @keywords internal
#' @aliases vroom-package
#' @useDynLib vroom, .registration = TRUE
"_PACKAGE"

## usethis namespace: start
#' @import rlang
#' @importFrom bit64 integer64
#' @importFrom crayon blue
#' @importFrom crayon bold
#' @importFrom crayon cyan
#' @importFrom crayon green
#' @importFrom crayon reset
#' @importFrom crayon silver
#' @importFrom glue glue
#' @importFrom lifecycle deprecate_warn
#' @importFrom lifecycle deprecated
## usethis namespace: end
NULL
