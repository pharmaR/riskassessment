# all col_types can be reported with color

    Code
      spec(dat)
    Output
      cols(
        skip = col_skip(),
        guess = [31mcol_character()[39m,
        character = [31mcol_character()[39m,
        factor = [31mcol_factor(levels = NULL, ordered = FALSE, include_na = FALSE)[39m,
        logical = [33mcol_logical()[39m,
        double = [32mcol_double()[39m,
        integer = [32mcol_integer()[39m,
        big_integer = [32mcol_big_integer()[39m,
        number = [32mcol_number()[39m,
        date = [34mcol_date(format = "")[39m,
        datetime = [34mcol_datetime(format = "")[39m,
        .delim = ","
      )

