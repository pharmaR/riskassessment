library(testthat)
library(vroom)

test_check("vroom")
