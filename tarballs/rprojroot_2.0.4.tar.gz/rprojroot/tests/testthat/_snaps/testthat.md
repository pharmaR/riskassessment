# is_testthat

    Code
      is_testthat
    Output
      Root criterion: directory name is "testthat" (also look in subdirectories: `tests/testthat`, `testthat`)

