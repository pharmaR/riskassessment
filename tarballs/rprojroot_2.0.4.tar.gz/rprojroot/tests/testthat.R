library(testthat)
library(rprojroot)

test_check("rprojroot")
