# Windows always uses OpenGL

noOpenGL <- FALSE
