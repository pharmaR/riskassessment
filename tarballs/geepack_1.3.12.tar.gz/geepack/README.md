# geepack
Generalized Estimating Equations
