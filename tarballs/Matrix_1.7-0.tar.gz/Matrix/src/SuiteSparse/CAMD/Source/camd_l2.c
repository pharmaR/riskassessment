//------------------------------------------------------------------------------
// CAMD/Source/camd_l2.c: int64_t version of camd_2
//------------------------------------------------------------------------------

// CAMD, Copyright (c) 2007-2022, Timothy A. Davis, Yanqing Chen, Patrick R.
// Amestoy, and Iain S. Duff.  All Rights Reserved.
// SPDX-License-Identifier: BSD-3-clause

//------------------------------------------------------------------------------

#define DLONG
#include "camd_2.c"

