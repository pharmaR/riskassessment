//------------------------------------------------------------------------------
// COLAMD/Source/colamd_l.c: int64_t version of colamd
//------------------------------------------------------------------------------

// COLAMD, Copyright (c) 1998-2022, Timothy A. Davis and Stefan Larimore,
// All Rights Reserved.
// SPDX-License-Identifier: BSD-3-clause

//------------------------------------------------------------------------------

#define DLONG
#include "colamd.c"

