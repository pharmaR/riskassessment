//------------------------------------------------------------------------------
// CXSparse/Source/cs_dl_entry.c: double, int64_t version of cs_entry
//------------------------------------------------------------------------------

// CXSparse, Copyright (c) 2006-2022, Timothy A. Davis, All Rights Reserved
// SPDX-License-Identifier: LGPL-2.1+

#define CS_LONG
#include "cs_entry.c"

