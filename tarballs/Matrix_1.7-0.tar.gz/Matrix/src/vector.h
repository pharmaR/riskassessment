#ifndef MATRIX_VECTOR_H
#define MATRIX_VECTOR_H

#include <Rinternals.h>

SEXP v2spV(SEXP);
SEXP CR2spV(SEXP);

#endif /* MATRIX_VECTOR_H */
