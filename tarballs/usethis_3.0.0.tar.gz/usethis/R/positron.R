is_positron <- function() {
  Sys.getenv("POSITRON") == "1"
}
