# use_github_links() aborts or appends URLs when it should

    Code
      use_github_links(overwrite = FALSE)
    Condition
      Error in `proj_desc_field_update()`:
      x 'URL' has a different value in DESCRIPTION. Use `overwrite = TRUE` to overwrite.

