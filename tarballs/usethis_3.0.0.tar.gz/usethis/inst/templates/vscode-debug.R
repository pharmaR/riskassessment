devtools::clean_dll()
devtools::load_all()

1 + 1
