admiralonco_environment <- new.env(parent = emptyenv())

# check_crpr.R ----
## signal_crpr
admiralonco_environment$crpr <- NULL
