library(testthat) # nolint: undesirable_function_linter
library(admiralonco) # nolint: undesirable_function_linter

test_check("admiralonco")
