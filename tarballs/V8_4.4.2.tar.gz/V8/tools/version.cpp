#include <v8.h>
#include <iostream>

int main(){
  std::cout << v8::V8::GetVersion();
}
