# quantiles fails outside 0-1 bound

    Problem while converting geom to grob.
    i Error occurred in the 1st layer.
    Caused by error in `draw_group()`:
    ! `draw_quantiles` must be between 0 and 1.

---

    Problem while converting geom to grob.
    i Error occurred in the 1st layer.
    Caused by error in `draw_group()`:
    ! `draw_quantiles` must be between 0 and 1.

