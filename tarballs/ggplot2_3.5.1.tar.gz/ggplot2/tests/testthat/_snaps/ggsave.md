# unknown device triggers error

    `device` must be a string, function or `NULL`, not the number 1.

# invalid single-string DPI values throw an error

    `dpi` must be one of "screen", "print", or "retina", not "abc".

# invalid non-single-string DPI values throw an error

    `dpi` must be a single number or string, not a <factor> object.

---

    `dpi` must be a single number or string, not a character vector.

---

    `dpi` must be a single number or string, not a double vector.

---

    `dpi` must be a single number or string, not a list.

