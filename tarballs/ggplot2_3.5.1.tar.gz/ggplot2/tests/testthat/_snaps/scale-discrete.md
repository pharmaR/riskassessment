# Aesthetics with no continuous interpretation fails when called

    A continuous variable cannot be mapped to the linetype aesthetic.
    i Choose a different aesthetic or use `scale_linetype_binned()`.

---

    A continuous variable cannot be mapped to the shape aesthetic.
    i Choose a different aesthetic or use `scale_shape_binned()`.

