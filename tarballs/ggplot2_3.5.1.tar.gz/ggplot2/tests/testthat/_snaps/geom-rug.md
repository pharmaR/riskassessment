# Rug length needs unit object

    Problem while converting geom to grob.
    i Error occurred in the 1st layer.
    Caused by error in `draw_panel()`:
    ! `length` must be a <unit> object, not the number 0.01.

