# stat_density2d can produce contour and raster data

    Problem while computing stat.
    i Error occurred in the 1st layer.
    Caused by error in `compute_layer()`:
    ! `contour_var` must be one of "density", "ndensity", or "count", not "abcd".

