library(testthat)
library(httr2)

test_check("httr2")
