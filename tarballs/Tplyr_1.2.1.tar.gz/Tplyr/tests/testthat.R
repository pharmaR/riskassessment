library(testthat)
library(Tplyr)

test_check("Tplyr")
