# Error handling - numeric

    If `where` is provided, a single `layer` value must be specified

---

    If `where` is provided, a single `layer` value must be specified

---

    Layer(s) blah do(es) not exist

---

    Layer(s) blah do(es) not exist

---

    Provided layer index is out of range

---

    Provided layer index is out of range

# Error handling - statistic

    If `where` is provided, `layer_name` and `statistic` must be specified

---

    If `where` is provided, `layer_name` and `statistic` must be specified

---

    Layer(s) blah do(es) not exist

---

    Layer(s) am, blah do(es) not exist

---

    Provided layer index is out of range

---

    Provided layer index is out of range

