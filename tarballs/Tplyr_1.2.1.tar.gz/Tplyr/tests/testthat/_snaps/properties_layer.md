# target_var errors raise appropriately

    Invalid input to `target_var`. Submit either a variable name or multiple variable names using `dplyr::vars`.

---

    Invalid input to `~quos(filter = Species2)`. Submit either a variable name or multiple variable names using `dplyr::vars`.

# by raises expected errors

    Invalid input to `~list(Species)`. Submit either a string, a variable name, or multiple variable names using `dplyr::vars`.

---

    Invalid input to `by`. Submit either a string, a variable name, or multiple variable names using `dplyr::vars`.

---

    Invalid input to `by`. Submit either a string, a variable name, or multiple variable names using `dplyr::vars`.

# where throws errors as expected

    The `where` parameter must contain subsetting logic (enter without quotes)

---

    The `where` parameter must contain subsetting logic (enter without quotes)

