# `add_risk_diff` can't be applied to a non-count layer

    Risk difference can only be applied to a count layer.

# Improper parameter entry is handled correctly

    Comparisons provided must be two-element character vectors

---

    Comparisons provided must be two-element character vectors

---

    All arguments provided via `args` must be valid arguments of `prop.test`

# Invalid name to format string call errors properly

    Invalid format names supplied. Count layers only accept the following format names: n_counts, riskdiff

# Error generates when duplicating riskdiff comparison values

    Comparison {4, 4} has duplicated values. Comparisons must not be duplicates

