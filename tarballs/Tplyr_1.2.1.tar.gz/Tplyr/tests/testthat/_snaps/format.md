# Format string must be character

    Argument `format_string` must be character. Instead a class of "numeric" was passed.

# Error is thrown when format doesn't match variables

    In `f_str` 2 formats were entered in the format string xx.x xx.xbut 1 variables were assigned.

---

    In `f_str` 1 formats were entered in the format string xx.xbut 2 variables were assigned.

