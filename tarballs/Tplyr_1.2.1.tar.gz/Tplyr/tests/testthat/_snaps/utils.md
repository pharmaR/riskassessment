# add_layer only accepts Tplyr functions

    Functions called within `add_layer` must be part of `Tplyr`

---

    Functions called within `add_layer` must be part of `Tplyr`

---

    Functions called within `add_layer` must be part of `Tplyr`

# Apply row masks errors trigger properly

    All parameters submitted through `...` must be variable names

---

    All parameters submitted through `...` must be variable names

---

    If `row_breaks` is specified, variables submitted via `...` must be `ord` variables included in the input data frame.
    Remember to sort prior to using `apply_row_masks`.

---

    If `row_breaks` is specified, variables submitted via `...` must be `ord` variables included in the input data frame.
    Remember to sort prior to using `apply_row_masks`.

---

    Break-by variables submitted via `...` must be 'Tplyr' order variables that start with `ord`

---

    Break-by variables submitted via `...` must be 'Tplyr' order variables that start with `ord`

