# pop_data binding throws expected errors

    'pop_data' argument passed to tplyr_table must be a data.frame,
    instead a class of: 'character' was passed.

---

    'pop_data' argument passed to tplyr_table must be a data.frame,
    instead a class of: 'array' was passed.

---

    'pop_data' argument passed to tplyr_table must be a data.frame,
    instead a class of: 'logical' was passed.

---

    'pop_data' argument passed to tplyr_table must be a data.frame,
    instead a class of: 'NULL' was passed.

# treat_var throws errors as expected

    treat_var column not found in target dataset

---

    treat_var column not found in target dataset

---

    A treat_var argument must be supplied

# pop_treat_var throws errors as expected

    pop_treat_var passed to tplyr_table is not a column of pop_data

---

    pop_treat_var passed to tplyr_table is not a column of pop_data

---

    pop_treat_var passed to tplyr_table is not a column of pop_data

