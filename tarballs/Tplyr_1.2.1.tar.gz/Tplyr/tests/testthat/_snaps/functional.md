# all test tables can be built without errors or warnings

    i In argument: `col_i = fct_expand(...)`.
    Caused by error:
    ! object 'col_i' not found

