# add_treat_grps errors function properly

    Treatment group arguments must have names

---

    Treatment groups can only be added to `tplyr_table` objects

# add_total_group errors function properly

    Argument `group_name` must be character. Instead a class of "numeric" was passed.

