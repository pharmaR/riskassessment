# apply_formats works correctly applies f_str() formatting

    i In argument: `fmt_example = apply_formats("a (xx.a)", hp, wt)`.
    Caused by error:
    ! Auto-precision is not currently supported within the `apply_formats()` context

