# Metadata extractors error properly

    Invalid row_id selected. row_id must be provided as a string present in built Tplyr table.

---

    Invalid row_id selected. row_id must be provided as a string present in built Tplyr table.

---

    column must provided as a character string and a valid result column present in the built Tplyr dataframe

---

    column must provided as a character string and a valid result column present in the built Tplyr dataframe

---

    Specified column must be a result column

---

    add_cols must be provided using `dplyr::vars()`

---

    If querying metadata without a tplyr_table, a target must be provided

