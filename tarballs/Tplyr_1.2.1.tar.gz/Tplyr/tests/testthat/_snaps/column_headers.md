# All columns must be character

    When binding headers, all columns must be character

# Nested headers are not allowed

    Nested spanning headers are not yet supported

# Header strings must have the same number of columns as the data frame

    i In index: 1.
    Caused by error:
    ! Number of columns provided in header string does not match data

---

    i In index: 1.
    Caused by error:
    ! Number of columns provided in header string does not match data

---

    i In index: 1.
    Caused by error:
    ! Number of columns provided in header string does not match data

---

    i In index: 1.
    Caused by error:
    ! Number of columns provided in header string does not match data

---

    i In index: 1.
    Caused by error:
    ! Number of columns provided in header string does not match data

---

    i In index: 1.
    Caused by error:
    ! Number of columns provided in header string does not match data

# Unmatched spanner brackers

    Unmatched brackets for spanning headers

# add_column_headers throws an error when you use a token and don't pass header_n

    i In index: 1.
    Caused by error:
    ! You must pass a header_n if you are using replacement tokens

