# All parameters must be provided

    `parent` parameter must be provided

---

    `layer` parameter must be provided

# Parent argument is a valid class (pass through to `tplyr_layer`)

    Must provide `tplyr_table` object from the `Tplyr` package.

# Only `Tplyr` methods are allowed in the `layer` parameter

    Functions called within `add_layer` must be part of `Tplyr`

