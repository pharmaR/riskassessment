#' @export lines.prodlim
lines.prodlim <- function(x,...){
  plot.prodlim(x,...,add=TRUE)
}
