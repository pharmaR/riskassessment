library(testthat)
library(IDEAFilter)
library(shinytest)
library(shinytest2)

test_check("IDEAFilter")
