options(riskmetric.tests = NULL)

stub_registry_clear()
httr_mock(FALSE)

rm(build_downloads)
