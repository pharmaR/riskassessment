#' A Test function
#'
#' @param x An object to print
#'
#' @return Nothing
#' @export
hello_world_test <- function(x) {
  print(paste0("hello world", x))
}
