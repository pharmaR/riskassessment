#' @family pkg_ref
pkg_cohort <- function() {
  structure(
    list(),
    class = "pkg_cohort"
  )
}
