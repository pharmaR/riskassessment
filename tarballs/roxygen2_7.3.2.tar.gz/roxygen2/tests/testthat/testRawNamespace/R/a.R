#' @import graphics
#' @rawNamespace
#' if (TRUE) {
#'   import(grDevices)
#' } else {
#'   import(methods)
#' }
#' @import utils
NULL
