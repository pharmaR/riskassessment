#' @include b.R
a <- 1
