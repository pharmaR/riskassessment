# missing title generates useful message

    Code
      roc_proc_text(rd_roclet(), block)
    Message
      x In topic 'foo.Rd': Skipping; no name and/or title.
    Output
      named list()

