# empty @param generates warning

    Code
      . <- roc_proc_text(rd_roclet(), block)
    Message
      x <text>:3: @param requires two parts: an argument name and a description.

