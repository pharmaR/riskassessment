# warn if forgotten colon

    Code
      . <- roc_proc_text(rd_roclet(), block)
    Message
      x <text>:4: @section title spans multiple lines..
      i Did you forget a colon (:) at the end of the title?

