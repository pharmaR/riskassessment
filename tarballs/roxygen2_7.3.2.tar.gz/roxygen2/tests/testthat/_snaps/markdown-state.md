# warning for both @md and @noMd

    Code
      out1 <- roc_proc_text(rd_roclet(), block)
    Message
      x <text>:5: @md conflicts with @noMd; turning markdown parsing off.

