globalVariables(c(".", ".data", ".rename_col", ".original_col","df_names","new_name_in_df",
                  "param_list", "label_quote", "label_collapse"))


## Shared variables
.tlang_delim <- "___tlang_delim___"
.tlang_struct_col_prefix <- "__tlang_span_structure_column__"
