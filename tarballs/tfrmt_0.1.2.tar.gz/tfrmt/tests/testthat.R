library(testthat)
library(tfrmt)

test_check("tfrmt")
