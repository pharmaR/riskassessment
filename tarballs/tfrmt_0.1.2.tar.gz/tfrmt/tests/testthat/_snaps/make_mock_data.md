# Check mock when value is missing

    Code
      out <- print_mock_gt(plan, data)
    Message
      Message: `tfrmt` will need `value` value to `print_to_gt` when data is avaliable

