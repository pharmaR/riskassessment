# arithmetic helpers throw default error

    Code
      add_years(x)
    Condition
      Error in `add_years()`:
      ! Can't perform this operation on a <numeric>.

---

    Code
      add_quarters(x)
    Condition
      Error in `add_quarters()`:
      ! Can't perform this operation on a <numeric>.

---

    Code
      add_months(x)
    Condition
      Error in `add_months()`:
      ! Can't perform this operation on a <numeric>.

---

    Code
      add_weeks(x)
    Condition
      Error in `add_weeks()`:
      ! Can't perform this operation on a <numeric>.

---

    Code
      add_days(x)
    Condition
      Error in `add_days()`:
      ! Can't perform this operation on a <numeric>.

---

    Code
      add_hours(x)
    Condition
      Error in `add_hours()`:
      ! Can't perform this operation on a <numeric>.

---

    Code
      add_minutes(x)
    Condition
      Error in `add_minutes()`:
      ! Can't perform this operation on a <numeric>.

---

    Code
      add_seconds(x)
    Condition
      Error in `add_seconds()`:
      ! Can't perform this operation on a <numeric>.

---

    Code
      add_milliseconds(x)
    Condition
      Error in `add_milliseconds()`:
      ! Can't perform this operation on a <numeric>.

---

    Code
      add_microseconds(x)
    Condition
      Error in `add_microseconds()`:
      ! Can't perform this operation on a <numeric>.

---

    Code
      add_nanoseconds(x)
    Condition
      Error in `add_nanoseconds()`:
      ! Can't perform this operation on a <numeric>.

