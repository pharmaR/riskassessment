# getters throw default error

    Code
      get_year(x)
    Condition
      Error in `get_year()`:
      ! Can't perform this operation on a <numeric>.

---

    Code
      get_quarter(x)
    Condition
      Error in `get_quarter()`:
      ! Can't perform this operation on a <numeric>.

---

    Code
      get_month(x)
    Condition
      Error in `get_month()`:
      ! Can't perform this operation on a <numeric>.

---

    Code
      get_week(x)
    Condition
      Error in `get_week()`:
      ! Can't perform this operation on a <numeric>.

---

    Code
      get_day(x)
    Condition
      Error in `get_day()`:
      ! Can't perform this operation on a <numeric>.

---

    Code
      get_hour(x)
    Condition
      Error in `get_hour()`:
      ! Can't perform this operation on a <numeric>.

---

    Code
      get_minute(x)
    Condition
      Error in `get_minute()`:
      ! Can't perform this operation on a <numeric>.

---

    Code
      get_second(x)
    Condition
      Error in `get_second()`:
      ! Can't perform this operation on a <numeric>.

---

    Code
      get_millisecond(x)
    Condition
      Error in `get_millisecond()`:
      ! Can't perform this operation on a <numeric>.

---

    Code
      get_microsecond(x)
    Condition
      Error in `get_microsecond()`:
      ! Can't perform this operation on a <numeric>.

---

    Code
      get_nanosecond(x)
    Condition
      Error in `get_nanosecond()`:
      ! Can't perform this operation on a <numeric>.

---

    Code
      get_index(x)
    Condition
      Error in `get_index()`:
      ! Can't perform this operation on a <numeric>.

