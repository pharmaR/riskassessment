library(testthat)
library(clock)

test_check("clock")
