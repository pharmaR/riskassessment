# This test case contains no executable code
# but it shouldn't throw an error
