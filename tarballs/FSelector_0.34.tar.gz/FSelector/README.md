FSelector: Selecting attributes
===============================

This package provides functions for selecting attributes from a given dataset. Attribute subset selection is the process of identifying and removing as much of the irrelevant and redundant information as possible.

CRAN page: http://cran.r-project.org/web/packages/FSelector/index.html
