# xml_child() errors if more than one search is given

    `1` and `2` must be of length 1.

