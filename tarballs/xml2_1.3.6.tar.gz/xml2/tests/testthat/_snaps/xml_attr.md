# xml_attrs<- modifies all attributes

    `test` must be a list of named character vectors.

