# write_xml errors for incorrect directory and with invalid inputs

    `file` must be a single string, not a character vector.

# write_xml works with nodeset input and connections

    `file` must be a single string, not a character vector.

# write_xml works with node input and files

    `file` must be a single string, not a character vector.

