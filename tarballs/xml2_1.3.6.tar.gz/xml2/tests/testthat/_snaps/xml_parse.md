# read_xml errors with an empty document

    `x` must be a single string, not an empty character vector.

# read_xml and read_html fail with > 1 input

    `x` must be a single string, not a character vector.

