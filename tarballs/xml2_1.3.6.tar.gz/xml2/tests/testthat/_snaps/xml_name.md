# error if missing ns spec

    Couldn't find prefix for url http://bar.com

