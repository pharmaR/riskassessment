# xml_structure is correct

    Code
      html_structure(quicklinks)
    Output
      <div.aux-content-widget-3.links.subnav [div]>
        {text}
        <h3>
          {text}
        {text}
        <div#maindetails_quicklinks>
          {text}
          <div.split_0>
            {text}
            <ul.quicklinks>
              <li.subnav_item_main>
                {text}
                <a.link [href]>
                  {text}
                {text}
              {text}
              <li.subnav_item_main>
                {text}
                <a.link [href]>
                  {text}
                {text}
              {text}
              <li.subnav_item_main>
                {text}
                <a.link [href]>
                  {text}
                {text}
              {text}
              <li.subnav_item_main>
                {text}
                <a.link [href]>
                  {text}
                {text}
              {text}
              <li.subnav_item_main>
                {text}
                <a.link [href]>
                  {text}
                {text}
              {text}
          {text}
          <div.split_1>
            {text}
            <ul.quicklinks>
              <li.subnav_item_main>
                {text}
                <a.link [href]>
                  {text}
                {text}
              {text}
              <li.subnav_item_main>
                {text}
                <a.link [href]>
                  {text}
                {text}
              {text}
              <li.subnav_item_main>
                {text}
                <a.link [href]>
                  {text}
                {text}
              {text}
              <li.subnav_item_main>
                {text}
                <a.link [href]>
                  {text}
                {text}
              {text}
              <li.subnav_item_main>
                {text}
                <a.link [href]>
                  {text}
                {text}
              {text}
          {text}
        {text}
        <hr>
        <div#full_subnav>
          {text}
          <h4>
            {text}
          {text}
          <ul.quicklinks>
            <li.subnav_item_main>
              {text}
              <a.link [href]>
                {text}
              {text}
            {text}
            <li.subnav_item_main>
              {text}
              <a.link [href]>
                {text}
              {text}
            {text}
            <li.subnav_item_main>
              {text}
              <a.link [href]>
                {text}
              {text}
            {text}
            <li.subnav_item_main>
              {text}
              <a.link [href]>
                {text}
              {text}
            {text}
            <li.subnav_item_main>
              {text}
              <a.link [href]>
                {text}
              {text}
            {text}
            <li.subnav_item_main>
              {text}
              <a.link [href]>
                {text}
              {text}
            {text}
            <li.subnav_item_main>
              {text}
              <a.link [href]>
                {text}
              {text}
            {text}
            <li.subnav_item_main>
              {text}
              <a.link.ghost [href]>
                {text}
              {text}
            {text}
          <h4>
            {text}
          {text}
          <ul.quicklinks>
            <li.subnav_item_main>
              {text}
              <a.link [href]>
                {text}
              {text}
            {text}
            <li.subnav_item_main>
              {text}
              <a.link [href]>
                {text}
              {text}
            {text}
            <li.subnav_item_main>
              {text}
              <a.link [href]>
                {text}
              {text}
            {text}
            <li.subnav_item_main>
              {text}
              <a.link [href]>
                {text}
              {text}
            {text}
            <li.subnav_item_main>
              {text}
              <a.link [href]>
                {text}
              {text}
            {text}
          <h4>
            {text}
          {text}
          <ul.quicklinks>
            <li.subnav_item_main>
              {text}
              <a.link [href]>
                {text}
              {text}
            {text}
            <li.subnav_item_main>
              {text}
              <a.link [href]>
                {text}
              {text}
            {text}
            <li.subnav_item_main>
              {text}
              <a.link [href]>
                {text}
              {text}
            {text}
            <li.subnav_item_main>
              {text}
              <a.link [href]>
                {text}
              {text}
            {text}
            <li.subnav_item_main>
              {text}
              <a.link.ghost [href]>
                {text}
              {text}
            {text}
            <li.subnav_item_main>
              {text}
              <a.link [href]>
                {text}
              {text}
            {text}
            <li.subnav_item_main>
              {text}
              <a.link [href]>
                {text}
              {text}
            {text}
          <h4>
            {text}
          {text}
          <ul.quicklinks>
            <li.subnav_item_main>
              {text}
              <a.link [href]>
                {text}
              {text}
            {text}
            <li.subnav_item_main>
              {text}
              <a.link [href]>
                {text}
              {text}
            {text}
          <h4>
            {text}
          {text}
          <ul.quicklinks>
            <li.subnav_item_main>
              {text}
              <a.link [href]>
                {text}
              {text}
            {text}
            <li.subnav_item_main>
              {text}
              <a.link.ghost [href]>
                {text}
              {text}
            {text}
            <li.subnav_item_main>
              {text}
              <a.link [href]>
                {text}
              {text}
            {text}
            <li.subnav_item_main>
              {text}
              <a.link [href]>
                {text}
              {text}
            {text}
            <li.subnav_item_main>
              {text}
              <a.link [href]>
                {text}
              {text}
            {text}
            <li.subnav_item_main>
              {text}
              <a.link [href]>
                {text}
              {text}
            {text}
            <li.subnav_item_main>
              {text}
              <a.link [href]>
                {text}
              {text}
            {text}
          <h4>
            {text}
          {text}
          <ul.quicklinks>
            <li.subnav_item_main>
              {text}
              <a.link [href]>
                {text}
              {text}
            {text}
          <h4>
            {text}
          {text}
          <ul.quicklinks>
            <li.subnav_item_main>
              {text}
              <a.link [href]>
                {text}
              {text}
            {text}
            <li.subnav_item_main>
              {text}
              <a.link.ghost [href]>
                {text}
              {text}
            {text}
            <li.subnav_item_main>
              {text}
              <a.link [href]>
                {text}
              {text}
            {text}
          <h4>
            {text}
          {text}
          <ul.quicklinks>
            <li.subnav_item_main>
              {text}
              <a.link [href]>
                {text}
              {text}
            {text}
            <li.subnav_item_main>
              {text}
              <a.link [href]>
                {text}
              {text}
            {text}
          <hr>
        {text}
        <div.show_more>
          <span.titlePageSprite.arrows.show>
          {text}
        {text}
        <div.show_less>
          <span.titlePageSprite.arrows.hide>
          {text}
        {text}

