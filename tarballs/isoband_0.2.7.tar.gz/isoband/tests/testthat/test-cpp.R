# Commented out to remove compile-time dependency on testthat
# run_cpp_tests("isoband")
