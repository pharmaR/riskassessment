# This dummy function definition is included with the package to ensure that
# 'tools::package_native_routine_registration_skeleton()' generates the required
# registration info for the 'run_testthat_tests' symbol.

# Commented out to remove compile-time dependency on testthat
#(function() {
#  .Call("run_testthat_tests", TRUE, PACKAGE = "isoband")
#})
