#' @useDynLib isoband, .registration = TRUE
#' @importFrom utils modifyList
#' @import grid
#' @keywords internal
"_PACKAGE"
