#' advfq_ophtha
#'
#' Visual Function Questionnaire Analysis
#'
#' @name advfq_ophtha
#' @docType data
#' @format A data frame with 89 columns:
#'   \describe{
#'     \item{ STUDYID }{Study Identifier}
#'     \item{ DOMAIN }{Domain Abbreviation}
#'     \item{ USUBJID }{Unique Subject Identifier}
#'     \item{ QSSEQ }{Sequence Number}
#'     \item{ QSTESTCD }{Question Short Name}
#'     \item{ QSTEST }{Question Name}
#'     \item{ QSCAT }{Category of Question}
#'     \item{ QSSCAT }{Subcategory for Question}
#'     \item{ QSORRES }{Finding in Original Units}
#'     \item{ QSORRESU }{Original Units}
#'     \item{ QSSTRESC }{Character Result/Finding in Std Format}
#'     \item{ QSSTRESN }{Numeric Finding in Standard Units}
#'     \item{ QSSTRESU }{Standard Units}
#'     \item{ QSBLFL }{Baseline Flag}
#'     \item{ QSDRVFL }{Derived Flag}
#'     \item{ VISITNUM }{Visit Number}
#'     \item{ VISIT }{Visit Name}
#'     \item{ VISITDY }{Planned Study Day of Visit}
#'     \item{ QSDTC }{Date/Time of Finding}
#'     \item{ QSDY }{Study Day of Finding}
#'     \item{ TRTSDT }{Date of First Exposure to Treatment}
#'     \item{ TRTEDT }{Date of Last Exposure to Treatment}
#'     \item{ TRT01A }{Actual Treatment for Period 01}
#'     \item{ TRT01P }{Planned Treatment for Period 01}
#'     \item{ ADT }{Analysis Date}
#'     \item{ ADY }{Analysis Relative Day}
#'     \item{ PARAMCD }{Parameter Code}
#'     \item{ AVAL }{Analysis Value}
#'     \item{ AVALC }{Analysis Value (C)}
#'     \item{ AVISIT }{Analysis Visit}
#'     \item{ AVISITN }{Analysis Visit (N)}
#'     \item{ ONTRTFL }{On Treatment Record Flag}
#'     \item{ ABLFL }{Baseline Record Flag}
#'     \item{ BASE }{Baseline Value}
#'     \item{ CHG }{Change from Baseline}
#'     \item{ PCHG }{Percent Change from Baseline}
#'     \item{ ANL01FL }{Analysis Flag 01}
#'     \item{ ASEQ }{Analysis Sequence Number}
#'     \item{ PARAM }{Parameter}
#'     \item{ PARCAT1 }{Parameter Category 1}
#'     \item{ PARCAT2 }{Parameter Category 2}
#'     \item{ SUBJID }{Subject Identifier for the Study}
#'     \item{ RFSTDTC }{Subject Reference Start Date/Time}
#'     \item{ RFENDTC }{Subject Reference End Date/Time}
#'     \item{ RFXSTDTC }{Date/Time of First Study Treatment}
#'     \item{ RFXENDTC }{Date/Time of Last Study Treatment}
#'     \item{ RFICDTC }{Date/Time of Informed Consent}
#'     \item{ RFPENDTC }{Date/Time of End of Participation}
#'     \item{ DTHDTC }{Date/Time of Death}
#'     \item{ DTHFL }{Subject Death Flag}
#'     \item{ SITEID }{Study Site Identifier}
#'     \item{ AGE }{Age}
#'     \item{ AGEU }{Age Units}
#'     \item{ SEX }{Sex}
#'     \item{ RACE }{Race}
#'     \item{ ETHNIC }{Ethnicity}
#'     \item{ ARMCD }{Planned Arm Code}
#'     \item{ ARM }{Description of Planned Arm}
#'     \item{ ACTARMCD }{Actual Arm Code}
#'     \item{ ACTARM }{Description of Actual Arm}
#'     \item{ COUNTRY }{Country}
#'     \item{ DMDTC }{Date/Time of Collection}
#'     \item{ DMDY }{Study Day of Collection}
#'     \item{ TRTSDTM }{Datetime of First Exposure to Treatment}
#'     \item{ TRTSTMF }{Time of First Exposure Imput. Flag}
#'     \item{ TRTEDTM }{Datetime of Last Exposure to Treatment}
#'     \item{ TRTETMF }{Time of Last Exposure Imput. Flag}
#'     \item{ TRTDURD }{Total Treatment Duration (Days)}
#'     \item{ SCRFDT }{Screen Failure Date}
#'     \item{ EOSDT }{End of Study Date}
#'     \item{ EOSSTT }{End of Study Status}
#'     \item{ FRVDT }{Final Retrievel Visit Date}
#'     \item{ RANDDT }{Date of Randomization}
#'     \item{ DTHDT }{Date of Death}
#'     \item{ DTHDTF }{undocumented field}
#'     \item{ DTHADY }{Relative Day of Death}
#'     \item{ LDDTHELD }{Elapsed Days from Last Dose to Death}
#'     \item{ DTHCAUS }{undocumented field}
#'     \item{ DTHDOM }{undocumented field}
#'     \item{ DTHCGR1 }{undocumented field}
#'     \item{ LSTALVDT }{Date Last Known Alive}
#'     \item{ SAFFL }{Safety Population Flag}
#'     \item{ RACEGR1 }{Pooled Race Group 1}
#'     \item{ AGEGR1 }{Pooled Age Group 1}
#'     \item{ REGION1 }{Geographic Region 1}
#'     \item{ LDDTHGR1 }{Last Dose to Death - Days Elapsed Grp 1}
#'     \item{ DTH30FL }{Death Within 30 Days of Last Trt Flag}
#'     \item{ DTHA30FL }{Death After 30 Days from Last Trt Flag}
#'     \item{ DTHB30FL }{Death Within 30 Days of First Trt Flag}
#'   }
#'
#' @source Generated from admiralophtha package (template ad_advfq.R).
#' @references None
#'
#' @examples
#' data("advfq_ophtha")
"advfq_ophtha"
