#' adtr_onco
#'
#' Tumor Results Analysis for Oncology
#'
#' @name adtr_onco
#' @docType data
#' @format A data frame with 99 columns:
#'   \describe{
#'     \item{ DOMAIN }{Domain Abbreviation}
#'     \item{ STUDYID }{Study Identifier}
#'     \item{ USUBJID }{Unique Subject Identifier}
#'     \item{ TRGRPID }{Group ID}
#'     \item{ TRLNKID }{Link ID}
#'     \item{ TRTESTCD }{Tumor/Lesion Assessment Short Name}
#'     \item{ TRTEST }{Tumor/Lesion Assessment Test Name}
#'     \item{ TRORRES }{Result or Finding in Original Units}
#'     \item{ TRORRESU }{Original Units}
#'     \item{ TRSTRESC }{Character Result/Finding in Std Format}
#'     \item{ TRSTRESN }{Numeric Result/Finding in Standard Units}
#'     \item{ TRSTRESU }{Standard Units}
#'     \item{ VISITNUM }{Visit Number}
#'     \item{ VISIT }{Visit Name}
#'     \item{ TREVAL }{Evaluator}
#'     \item{ TREVALID }{Evaluator Identifier}
#'     \item{ TRACPTFL }{Accepted Record Flag}
#'     \item{ TRDTC }{Date/Time of Tumor/Lesion Measurement}
#'     \item{ TRSEQ }{Sequence Number}
#'     \item{ RANDDT }{Date of Randomization}
#'     \item{ TULOC }{Location of the Tumor/Lesion}
#'     \item{ TULOCGR1 }{Tumor Site Group 1}
#'     \item{ LSEXP }{Lesion IDs Expected}
#'     \item{ LSASS }{Lesion IDs Assessed}
#'     \item{ ADT }{Analysis Date}
#'     \item{ ADTF }{Analysis Date Imputation Flag}
#'     \item{ ADY }{Analysis Relative Day}
#'     \item{ AVISIT }{Analysis Visit}
#'     \item{ AVISITN }{Analysis Visit (N)}
#'     \item{ PARAMCD }{Parameter Code}
#'     \item{ PARAM }{Parameter}
#'     \item{ PARCAT1 }{Parameter Category 1}
#'     \item{ PARCAT2 }{Parameter Category 2}
#'     \item{ PARCAT3 }{Parameter Category 3}
#'     \item{ AVAL }{Analysis Value}
#'     \item{ ANL01FL }{Analysis Flag 01}
#'     \item{ ABLFL }{Baseline Record Flag}
#'     \item{ BASE }{Baseline Value}
#'     \item{ NADIR }{NADIR}
#'     \item{ CHG }{Change from Baseline}
#'     \item{ PCHG }{Percent Change from Baseline}
#'     \item{ CHGNAD }{Change from NADIR}
#'     \item{ PCHGNAD }{Percent Change from NADIR}
#'     \item{ PDFL }{Pharmacodynamic Analysis Set Flag}
#'     \item{ ANL02FL }{Analysis Flag 02}
#'     \item{ ANL03FL }{Analysis Flag 03}
#'     \item{ ANL04FL }{Analysis Flag 04}
#'     \item{ ASEQ }{Analysis Sequence Number}
#'     \item{ SUBJID }{Subject Identifier for the Study}
#'     \item{ RFSTDTC }{Subject Reference Start Date/Time}
#'     \item{ RFENDTC }{Subject Reference End Date/Time}
#'     \item{ RFXSTDTC }{Date/Time of First Study Treatment}
#'     \item{ RFXENDTC }{Date/Time of Last Study Treatment}
#'     \item{ RFICDTC }{Date/Time of Informed Consent}
#'     \item{ RFPENDTC }{Date/Time of End of Participation}
#'     \item{ DTHDTC }{Date/Time of Death}
#'     \item{ DTHFL }{Subject Death Flag}
#'     \item{ SITEID }{Study Site Identifier}
#'     \item{ AGE }{Age}
#'     \item{ AGEU }{Age Units}
#'     \item{ SEX }{Sex}
#'     \item{ RACE }{Race}
#'     \item{ ETHNIC }{Ethnicity}
#'     \item{ ARMCD }{Planned Arm Code}
#'     \item{ ARM }{Description of Planned Arm}
#'     \item{ ACTARMCD }{Actual Arm Code}
#'     \item{ ACTARM }{Description of Actual Arm}
#'     \item{ COUNTRY }{Country}
#'     \item{ DMDTC }{Date/Time of Collection}
#'     \item{ DMDY }{Study Day of Collection}
#'     \item{ TRT01P }{Planned Treatment for Period 01}
#'     \item{ TRT01A }{Actual Treatment for Period 01}
#'     \item{ TRTSDTM }{Datetime of First Exposure to Treatment}
#'     \item{ TRTSTMF }{Time of First Exposure Imput. Flag}
#'     \item{ TRTEDTM }{Datetime of Last Exposure to Treatment}
#'     \item{ TRTETMF }{Time of Last Exposure Imput. Flag}
#'     \item{ TRTSDT }{Date of First Exposure to Treatment}
#'     \item{ TRTEDT }{Date of Last Exposure to Treatment}
#'     \item{ TRTDURD }{Total Treatment Duration (Days)}
#'     \item{ SCRFDT }{Screen Failure Date}
#'     \item{ EOSDT }{End of Study Date}
#'     \item{ EOSSTT }{End of Study Status}
#'     \item{ FRVDT }{Final Retrievel Visit Date}
#'     \item{ DTHDT }{Date of Death}
#'     \item{ DTHDTF }{Date of Death Imputation Flag}
#'     \item{ DTHADY }{Relative Day of Death}
#'     \item{ LDDTHELD }{Elapsed Days from Last Dose to Death}
#'     \item{ DTHCAUS }{Cause of Death}
#'     \item{ DTHDOM }{Domain for Date of Death Collection}
#'     \item{ DTHCGR1 }{Cause of Death Reason 1}
#'     \item{ LSTALVDT }{Date Last Known Alive}
#'     \item{ SAFFL }{Safety Population Flag}
#'     \item{ RACEGR1 }{Pooled Race Group 1}
#'     \item{ AGEGR1 }{Pooled Age Group 1}
#'     \item{ REGION1 }{Geographic Region 1}
#'     \item{ LDDTHGR1 }{Last Dose to Death - Days Elapsed Grp 1}
#'     \item{ DTH30FL }{Death Within 30 Days of Last Trt Flag}
#'     \item{ DTHA30FL }{Death After 30 Days from Last Trt Flag}
#'     \item{ DTHB30FL }{Death Within 30 Days of First Trt Flag}
#'   }
#'
#' @source Generated from admiralonco package (template ad_adtr.R).
#' @references None
#'
#' @examples
#' data("adtr_onco")
"adtr_onco"
