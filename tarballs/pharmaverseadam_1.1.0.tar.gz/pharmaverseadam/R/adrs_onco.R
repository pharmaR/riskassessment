#' adrs_onco
#'
#' Tumor Response Analysis
#'
#' @name adrs_onco
#' @docType data
#' @format A data frame with 79 columns:
#'   \describe{
#'     \item{ DOMAIN }{Domain Abbreviation}
#'     \item{ STUDYID }{Study Identifier}
#'     \item{ USUBJID }{Unique Subject Identifier}
#'     \item{ VISITNUM }{Visit Number}
#'     \item{ VISIT }{Visit Name}
#'     \item{ RSTESTCD }{Assessment Short Name}
#'     \item{ RSTEST }{Assessment Name}
#'     \item{ RSORRES }{Result or Finding in Original Units}
#'     \item{ RSSTRESC }{Character Result/Finding in Std Format}
#'     \item{ RSEVAL }{Evaluator}
#'     \item{ RSEVALID }{Evaluator Identifier}
#'     \item{ RSACPTFL }{Accepted Record Flag}
#'     \item{ RSDTC }{Date/Time of Assessment}
#'     \item{ RSSEQ }{Sequence Number}
#'     \item{ RANDDT }{Date of Randomization}
#'     \item{ PARAMCD }{Parameter Code}
#'     \item{ PARAM }{Parameter}
#'     \item{ PARCAT1 }{Parameter Category 1}
#'     \item{ PARCAT2 }{Parameter Category 2}
#'     \item{ PARCAT3 }{Parameter Category 3}
#'     \item{ ADT }{Analysis Date}
#'     \item{ ADTF }{Analysis Date Imputation Flag}
#'     \item{ AVISIT }{Analysis Visit}
#'     \item{ AVALC }{Analysis Value (C)}
#'     \item{ AVAL }{Analysis Value}
#'     \item{ ANL01FL }{Analysis Flag 01}
#'     \item{ ANL02FL }{Analysis Flag 02}
#'     \item{ ASEQ }{Analysis Sequence Number}
#'     \item{ SUBJID }{Subject Identifier for the Study}
#'     \item{ RFSTDTC }{Subject Reference Start Date/Time}
#'     \item{ RFENDTC }{Subject Reference End Date/Time}
#'     \item{ RFXSTDTC }{Date/Time of First Study Treatment}
#'     \item{ RFXENDTC }{Date/Time of Last Study Treatment}
#'     \item{ RFICDTC }{Date/Time of Informed Consent}
#'     \item{ RFPENDTC }{Date/Time of End of Participation}
#'     \item{ DTHDTC }{Date/Time of Death}
#'     \item{ DTHFL }{Subject Death Flag}
#'     \item{ SITEID }{Study Site Identifier}
#'     \item{ AGE }{Age}
#'     \item{ AGEU }{Age Units}
#'     \item{ SEX }{Sex}
#'     \item{ RACE }{Race}
#'     \item{ ETHNIC }{Ethnicity}
#'     \item{ ARMCD }{Planned Arm Code}
#'     \item{ ARM }{Description of Planned Arm}
#'     \item{ ACTARMCD }{Actual Arm Code}
#'     \item{ ACTARM }{Description of Actual Arm}
#'     \item{ COUNTRY }{Country}
#'     \item{ DMDTC }{Date/Time of Collection}
#'     \item{ DMDY }{Study Day of Collection}
#'     \item{ TRT01P }{Planned Treatment for Period 01}
#'     \item{ TRT01A }{Actual Treatment for Period 01}
#'     \item{ TRTSDTM }{Datetime of First Exposure to Treatment}
#'     \item{ TRTSTMF }{Time of First Exposure Imput. Flag}
#'     \item{ TRTEDTM }{Datetime of Last Exposure to Treatment}
#'     \item{ TRTETMF }{Time of Last Exposure Imput. Flag}
#'     \item{ TRTSDT }{Date of First Exposure to Treatment}
#'     \item{ TRTEDT }{Date of Last Exposure to Treatment}
#'     \item{ TRTDURD }{Total Treatment Duration (Days)}
#'     \item{ SCRFDT }{Screen Failure Date}
#'     \item{ EOSDT }{End of Study Date}
#'     \item{ EOSSTT }{End of Study Status}
#'     \item{ FRVDT }{Final Retrievel Visit Date}
#'     \item{ DTHDT }{Date of Death}
#'     \item{ DTHDTF }{Date of Death Imputation Flag}
#'     \item{ DTHADY }{Relative Day of Death}
#'     \item{ LDDTHELD }{Elapsed Days from Last Dose to Death}
#'     \item{ DTHCAUS }{Cause of Death}
#'     \item{ DTHDOM }{Domain for Date of Death Collection}
#'     \item{ DTHCGR1 }{Cause of Death Reason 1}
#'     \item{ LSTALVDT }{Date Last Known Alive}
#'     \item{ SAFFL }{Safety Population Flag}
#'     \item{ RACEGR1 }{Pooled Race Group 1}
#'     \item{ AGEGR1 }{Pooled Age Group 1}
#'     \item{ REGION1 }{Geographic Region 1}
#'     \item{ LDDTHGR1 }{Last Dose to Death - Days Elapsed Grp 1}
#'     \item{ DTH30FL }{Death Within 30 Days of Last Trt Flag}
#'     \item{ DTHA30FL }{Death After 30 Days from Last Trt Flag}
#'     \item{ DTHB30FL }{Death Within 30 Days of First Trt Flag}
#'   }
#'
#' @source Generated from admiralonco package (template ad_adrs.R).
#' @references None
#'
#' @examples
#' data("adrs_onco")
"adrs_onco"
