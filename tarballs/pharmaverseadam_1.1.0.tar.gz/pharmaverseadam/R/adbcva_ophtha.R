#' adbcva_ophtha
#'
#' Best Corrected Visual Acuity Analysis
#'
#' @name adbcva_ophtha
#' @docType data
#' @format A data frame with 120 columns:
#'   \describe{
#'     \item{ STUDYID }{Study Identifier}
#'     \item{ DOMAIN }{Domain Abbreviation}
#'     \item{ USUBJID }{Unique Subject Identifier}
#'     \item{ OESEQ }{Sequence Number}
#'     \item{ OECAT }{Category for Ophthalmic Test or Exam}
#'     \item{ OESCAT }{Subcategory for Ophthalmic Test or Exam}
#'     \item{ OEDTC }{Date/Time of Collection}
#'     \item{ VISIT }{Visit Name}
#'     \item{ VISITNUM }{Visit Number}
#'     \item{ VISITDY }{Planned Study Day of Visit}
#'     \item{ OESTRESN }{Numeric Result/Finding in Standard Units}
#'     \item{ OESTRESC }{Character Result/Finding in Std Format}
#'     \item{ OEORRES }{Result or Finding in Original Units}
#'     \item{ OETEST }{Name of Ophthalmic Test or Exam}
#'     \item{ OETESTCD }{Short Name of Ophthalmic Test or Exam}
#'     \item{ OETSTDTL }{Ophthalmic Test or Exam Detail}
#'     \item{ OELAT }{Laterality}
#'     \item{ OELOC }{Location Used for the Measurement}
#'     \item{ OEDY }{Study Day of Visit/Collection/Exam}
#'     \item{ OEMETHOD }{Method of Test or Examination}
#'     \item{ OEORRESU }{Original Units}
#'     \item{ OESTRESU }{Standard Units}
#'     \item{ OESTAT }{Completion Status}
#'     \item{ OETPT }{Planned Time Point Name}
#'     \item{ OETPTNUM }{Planned Time Point Number}
#'     \item{ TRTSDT }{Date of First Exposure to Treatment}
#'     \item{ TRTEDT }{Date of Last Exposure to Treatment}
#'     \item{ TRT01A }{Actual Treatment for Period 01}
#'     \item{ TRT01P }{Planned Treatment for Period 01}
#'     \item{ STUDYEYE }{Study Eye Location}
#'     \item{ AVAL }{Analysis Value}
#'     \item{ AVALU }{Analysis Value Unit}
#'     \item{ DTYPE }{Derivation Type}
#'     \item{ AFEYE }{Affected Eye}
#'     \item{ PARAM }{Parameter}
#'     \item{ PARAMCD }{Parameter Code}
#'     \item{ AVALC }{Analysis Value (C)}
#'     \item{ ADT }{Analysis Date}
#'     \item{ ADY }{Analysis Relative Day}
#'     \item{ ATPTN }{Analysis Timepoint (N)}
#'     \item{ ATPT }{Analysis Timepoint}
#'     \item{ AVISIT }{Analysis Visit}
#'     \item{ AVISITN }{Analysis Visit (N)}
#'     \item{ BASETYPE }{Baseline Type}
#'     \item{ ONTRTFL }{On Treatment Record Flag}
#'     \item{ ABLFL }{Baseline Record Flag}
#'     \item{ ANL01FL }{Analysis Flag 01}
#'     \item{ ANL02FL }{Analysis Flag 02}
#'     \item{ WORS01FL }{Worst Post Baseline Obs}
#'     \item{ BASE }{Baseline Value}
#'     \item{ BASEC }{Baseline Value (C)}
#'     \item{ CHG }{Change from Baseline}
#'     \item{ PCHG }{Percent Change from Baseline}
#'     \item{ ASEQ }{Analysis Sequence Number}
#'     \item{ SUBJID }{Subject Identifier for the Study}
#'     \item{ RFSTDTC }{Subject Reference Start Date/Time}
#'     \item{ RFENDTC }{Subject Reference End Date/Time}
#'     \item{ RFXSTDTC }{Date/Time of First Study Treatment}
#'     \item{ RFXENDTC }{Date/Time of Last Study Treatment}
#'     \item{ RFICDTC }{Date/Time of Informed Consent}
#'     \item{ RFPENDTC }{Date/Time of End of Participation}
#'     \item{ DTHDTC }{Date/Time of Death}
#'     \item{ DTHFL }{Subject Death Flag}
#'     \item{ SITEID }{Study Site Identifier}
#'     \item{ AGE }{Age}
#'     \item{ AGEU }{Age Units}
#'     \item{ SEX }{Sex}
#'     \item{ RACE }{Race}
#'     \item{ ETHNIC }{Ethnicity}
#'     \item{ ARMCD }{Planned Arm Code}
#'     \item{ ARM }{Description of Planned Arm}
#'     \item{ ACTARMCD }{Actual Arm Code}
#'     \item{ ACTARM }{Description of Actual Arm}
#'     \item{ COUNTRY }{Country/Region}
#'     \item{ DMDTC }{Date/Time of Collection}
#'     \item{ DMDY }{Study Day of Collection}
#'     \item{ TRTSDTM }{Datetime of First Exposure to Treatment}
#'     \item{ TRTSTMF }{Time of First Exposure Imput. Flag}
#'     \item{ TRTEDTM }{Datetime of Last Exposure to Treatment}
#'     \item{ TRTETMF }{Time of Last Exposure Imput. Flag}
#'     \item{ TRTDURD }{Total Treatment Duration (Days)}
#'     \item{ SCRFDT }{Screen Failure Date}
#'     \item{ EOSDT }{End of Study Date}
#'     \item{ EOSSTT }{End of Study Status}
#'     \item{ FRVDT }{Final Retrievel Visit Date}
#'     \item{ RANDDT }{Date of Randomization}
#'     \item{ DTHDT }{Date of Death}
#'     \item{ DTHDTF }{undocumented field}
#'     \item{ DTHADY }{Relative Day of Death}
#'     \item{ LDDTHELD }{Elapsed Days from Last Dose to Death}
#'     \item{ DTHCAUS }{undocumented field}
#'     \item{ DTHDOM }{undocumented field}
#'     \item{ DTHCGR1 }{undocumented field}
#'     \item{ LSTALVDT }{Date Last Known Alive}
#'     \item{ SAFFL }{Safety Population Flag}
#'     \item{ RACEGR1 }{Pooled Race Group 1}
#'     \item{ AGEGR1 }{Pooled Age Group 1}
#'     \item{ REGION1 }{Geographic Region 1}
#'     \item{ LDDTHGR1 }{Last Dose to Death - Days Elapsed Grp 1}
#'     \item{ DTH30FL }{Death Within 30 Days of Last Trt Flag}
#'     \item{ DTHA30FL }{Death After 30 Days from Last Trt Flag}
#'     \item{ DTHB30FL }{Death Within 30 Days of First Trt Flag}
#'     \item{ CRIT1 }{Analysis Criterion 1}
#'     \item{ CRIT1FL }{Criterion 1 Evaluation Result Flag}
#'     \item{ CRIT2 }{Analysis Criterion 2}
#'     \item{ CRIT2FL }{Criterion 2 Evaluation Result Flag}
#'     \item{ CRIT3 }{Analysis Criterion 3}
#'     \item{ CRIT3FL }{Criterion 3 Evaluation Result Flag}
#'     \item{ CRIT4 }{Analysis Criterion 4}
#'     \item{ CRIT4FL }{Criterion 4 Evaluation Result Flag}
#'     \item{ CRIT5 }{Analysis Criterion 5}
#'     \item{ CRIT5FL }{Criterion 5 Evaluation Result Flag}
#'     \item{ CRIT6 }{Analysis Criterion 6}
#'     \item{ CRIT6FL }{Criterion 6 Evaluation Result Flag}
#'     \item{ CRIT7 }{Analysis Criterion 7}
#'     \item{ CRIT7FL }{Criterion 7 Evaluation Result Flag}
#'     \item{ CRIT8 }{Analysis Criterion 8}
#'     \item{ CRIT8FL }{Criterion 8 Evaluation Result Flag}
#'     \item{ AVALCA1N }{Analysis Value Category 1 (N)}
#'     \item{ AVALCAT1 }{Analysis Value Category 1}
#'   }
#'
#' @source Generated from admiralophtha package (template ad_adbcva.R).
#' @references None
#'
#' @examples
#' data("adbcva_ophtha")
"adbcva_ophtha"
