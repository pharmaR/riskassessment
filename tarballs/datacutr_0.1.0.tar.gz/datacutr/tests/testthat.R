library(testthat)
library(datacutr)

test_check("datacutr")
