library(testthat)
library(rvest)

test_check("rvest")
