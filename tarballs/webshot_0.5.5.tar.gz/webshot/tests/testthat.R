library(testthat)
library(webshot)

test_check("webshot")
