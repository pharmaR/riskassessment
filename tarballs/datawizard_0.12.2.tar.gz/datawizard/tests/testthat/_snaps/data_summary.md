# data_summary, print

    Code
      print(out)
    Output
      am | gear |    MW |   SD
      ------------------------
       0 |    3 | 16.11 | 3.37
       0 |    4 | 21.05 | 3.07
       1 |    4 | 26.27 | 5.41
       1 |    5 | 21.38 | 6.66

# data_summary, with NA

    Code
      print(out)
    Output
      c172code |    MW
      ----------------
             1 | 87.12
             2 | 94.05
             3 | 75.00
          <NA> | 47.80

---

    Code
      print(out)
    Output
      c172code |    MW
      ----------------
             1 | 87.12
             2 | 94.05
             3 | 75.00

---

    Code
      print(out)
    Output
      e42dep | c172code |     MW
      --------------------------
      1      |        2 |  17.00
      2      |        2 |  34.25
      3      |        1 |  39.50
      3      |        2 |  52.44
      3      |        3 |  52.00
      3      |     <NA> |  84.00
      4      |        1 | 134.75
      4      |        2 | 119.26
      4      |        3 |  88.80
      4      |     <NA> |  43.29
      <NA>   |        2 |   <NA>
      <NA>   |     <NA> |   7.00

