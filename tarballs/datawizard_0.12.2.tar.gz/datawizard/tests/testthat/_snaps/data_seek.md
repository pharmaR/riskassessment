# data_seek - print

    Code
      data_seek(iris, "Length")
    Output
      index |       column |       labels
      -----------------------------------
          1 | Sepal.Length | Sepal.Length
          3 | Petal.Length | Petal.Length

---

    Code
      data_seek(iris, "abc")
    Output
      No matches found.

