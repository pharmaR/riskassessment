if (require("testthat", quietly = TRUE)) {
  library(sourcetools)
  test_check("sourcetools")
}
