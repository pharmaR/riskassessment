# prepend is deprecated

    Code
      . <- prepend(1, 2)
    Condition
      Warning:
      `prepend()` was deprecated in purrr 1.0.0.
      i Please use append(after = 0) instead.

