# assign_in() requires at least one location

    Code
      assign_in(x, NULL, value = "foo")
    Condition
      Error in `assign_in()`:
      ! `where` must contain at least one element.

