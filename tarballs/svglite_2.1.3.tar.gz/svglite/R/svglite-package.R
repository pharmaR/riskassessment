#' @keywords internal
#' @aliases svglite-package
"_PACKAGE"

## usethis namespace: start
## usethis namespace: end
NULL
