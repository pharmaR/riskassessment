library("testthat")
library("pkglite")

test_check("pkglite")
