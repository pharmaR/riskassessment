# pkg2

An example R package.
