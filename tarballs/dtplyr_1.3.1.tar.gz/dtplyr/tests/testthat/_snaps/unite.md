# errors on na.rm

    `na.rm` is not implemented in dtplyr

