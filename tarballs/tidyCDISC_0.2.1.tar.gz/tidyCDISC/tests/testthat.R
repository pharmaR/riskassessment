library(testthat)
library(tidyCDISC)
library(shinyjs)

test_check("tidyCDISC")
