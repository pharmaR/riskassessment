# lat lon

    Code
      near_station <- recipe(~., data = postal) %>% step_geodist(lat = latitude, lon = longitude,
        log = FALSE, ref_lat = 100, ref_lon = 100, is_lat_lon = TRUE) %>% prep()
    Condition
      Error in `step_geodist()`:
      ! `ref_lat` must be a number between -90 and 90, not the number 100.

---

    Code
      near_station <- recipe(~., data = postal) %>% step_geodist(lat = latitude, lon = longitude,
        log = FALSE, ref_lat = 0, ref_lon = 190, is_lat_lon = TRUE) %>% prep()
    Condition
      Error in `step_geodist()`:
      ! `ref_lon` must be a number between -180 and 180, not the number 190.

---

    Code
      near_station <- recipe(~., data = postal) %>% step_geodist(lat = latitude, lon = longitude,
        log = FALSE, ref_lat = -100, ref_lon = 0, is_lat_lon = TRUE) %>% prep()
    Condition
      Error in `step_geodist()`:
      ! `ref_lat` must be a number between -90 and 90, not the number -100.

---

    Code
      near_station <- recipe(~., data = postal) %>% step_geodist(lat = latitude, lon = longitude,
        log = FALSE, ref_lat = 0, ref_lon = -190, is_lat_lon = TRUE) %>% prep()
    Condition
      Error in `step_geodist()`:
      ! `ref_lon` must be a number between -180 and 180, not the number -190.

---

    Code
      near_station <- recipe(~., data = postal) %>% step_geodist(lat = latitude, lon = longitude,
        log = FALSE, ref_lat = 38.8986312, ref_lon = -77.0062457, is_lat_lon = TRUE) %>%
        prep()
    Condition
      Error in `step_geodist()`:
      Caused by error in `bake()`:
      ! All `lat` values should be between -90 and 90.

---

    Code
      near_station <- recipe(~., data = postal) %>% step_geodist(lat = latitude, lon = longitude,
        log = FALSE, ref_lat = 38.8986312, ref_lon = -77.0062457, is_lat_lon = TRUE) %>%
        prep()
    Condition
      Error in `step_geodist()`:
      Caused by error in `bake()`:
      ! All `lon` values should be between -180 and 180.

---

    Code
      near_station <- recipe(~., data = postal) %>% step_geodist(lat = latitude, lon = longitude,
        log = FALSE, ref_lat = 38.8986312, ref_lon = -77.0062457, is_lat_lon = TRUE) %>%
        prep()
    Condition
      Error in `step_geodist()`:
      Caused by error in `bake()`:
      ! All `lat` values should be between -90 and 90.

---

    Code
      near_station <- recipe(~., data = postal) %>% step_geodist(lat = latitude, lon = longitude,
        log = FALSE, ref_lat = 38.8986312, ref_lon = -77.0062457, is_lat_lon = TRUE) %>%
        prep()
    Condition
      Error in `step_geodist()`:
      Caused by error in `bake()`:
      ! All `lon` values should be between -180 and 180.

# check_name() is used

    Code
      prep(rec, training = dat)
    Condition
      Error in `step_geodist()`:
      Caused by error in `bake()`:
      ! Name collision occurred. The following variable names already exist:
      * `geo_dist`

# bad args

    Code
      rec %>% step_geodist(starts_with("x"), y, ref_lat = 0.5, ref_lon = 0.25) %>%
        prep(training = rand_data_2)
    Condition
      Error in `step_geodist()`:
      Caused by error in `prep()`:
      x The `lat` selector should select at most a single variable.
      i The following 2 were selected: `x` and `x1`.

---

    Code
      rec %>% step_geodist(x, starts_with("y"), ref_lat = 0.5, ref_lon = 0.25) %>%
        prep(training = rand_data_2)
    Condition
      Error in `step_geodist()`:
      Caused by error in `prep()`:
      x The `lon` selector should select at most a single variable.
      i The following 2 were selected: `y` and `y1`.

---

    Code
      rec %>% step_geodist(x, y, ref_lat = letters[1:2], ref_lon = 0.25) %>% prep(
        training = rand_data_2)
    Condition
      Error in `step_geodist()`:
      ! `ref_lat` must be a number, not a character vector.

---

    Code
      rec %>% step_geodist(x, y, ref_lon = letters[1:2], ref_lat = 0.25) %>% prep(
        training = rand_data_2)
    Condition
      Error in `step_geodist()`:
      ! `ref_lon` must be a number, not a character vector.

---

    Code
      rec %>% step_geodist(x, y, ref_lon = 0.5, ref_lat = 0.25, name = 1) %>% prep(
        training = rand_data_2)
    Condition
      Error in `step_geodist()`:
      ! `name` must be a single string, not the number 1.

---

    Code
      rec %>% step_geodist(x, y, ref_lon = 0.5, ref_lat = 0.25, log = exp(1)) %>%
        prep(training = rand_data_2)
    Condition
      Error in `step_geodist()`:
      ! `log` must be `TRUE` or `FALSE`, not the number 2.72.

---

    Code
      recipe(~ x + y, data = rand_data) %>% step_geodist(x, y, ref_lat = 0.5,
        ref_lon = 0.25, is_lat_lon = "no", log = FALSE) %>% prep(training = rand_data)
    Condition
      Error in `step_geodist()`:
      ! `is_lat_lon` must be `TRUE` or `FALSE`, not the string "no".

---

    Code
      recipe(~ x + y, data = rand_data) %>% step_geodist(x, y, ref_lat = 0.5,
        ref_lon = 0.25, is_lat_lon = c(TRUE, TRUE), log = FALSE) %>% prep(training = rand_data)
    Condition
      Error in `step_geodist()`:
      ! `is_lat_lon` must be `TRUE` or `FALSE`, not a logical vector.

# empty printing

    Code
      rec
    Message
      
      -- Recipe ----------------------------------------------------------------------
      
      -- Inputs 
      Number of variables by role
      outcome:    1
      predictor: 10
      
      -- Operations 
      * Geographical distances from 0.5 x 0.25 using: NULL and NULL

---

    Code
      rec
    Message
      
      -- Recipe ----------------------------------------------------------------------
      
      -- Inputs 
      Number of variables by role
      outcome:    1
      predictor: 10
      
      -- Training information 
      Training data contained 32 data points and no incomplete rows.
      
      -- Operations 
      * Geographical distances from 0.5 x 0.25 using: <none> | Trained

# keep_original_cols - can prep recipes with it missing

    Code
      rec <- prep(rec)
    Condition
      Warning:
      `keep_original_cols` was added to `step_geodist()` after this recipe was created.
      i Regenerate your recipe to avoid this warning.

# printing

    Code
      print(rec)
    Message
      
      -- Recipe ----------------------------------------------------------------------
      
      -- Inputs 
      Number of variables by role
      predictor: 2
      
      -- Operations 
      * Geographical distances from 0.5 x 0.25 using: x and y

---

    Code
      prep(rec)
    Message
      
      -- Recipe ----------------------------------------------------------------------
      
      -- Inputs 
      Number of variables by role
      predictor: 2
      
      -- Training information 
      Training data contained 10 data points and 1 incomplete row.
      
      -- Operations 
      * Geographical distances from 0.5 x 0.25 using: x and y | Trained

