# Deprecation error

    Code
      recipe(~., data = mtcars) %>% step_bagimpute()
    Condition
      Error:
      ! `step_bagimpute()` was deprecated in recipes 0.1.16 and is now defunct.
      i Please use `step_impute_bag()` instead.

