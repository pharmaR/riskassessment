# Deprecation error

    Code
      recipe(~., data = mtcars) %>% step_knnimpute()
    Condition
      Error:
      ! `step_knnimpute()` was deprecated in recipes 0.1.16 and is now defunct.
      i Please use `step_impute_knn()` instead.

