# Deprecation error

    Code
      recipe(~., data = mtcars) %>% step_rollimpute()
    Condition
      Error:
      ! `step_rollimpute()` was deprecated in recipes 0.1.16 and is now defunct.
      i Please use `step_impute_roll()` instead.

