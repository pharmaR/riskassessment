# Deprecation error

    Code
      recipe(~., data = mtcars) %>% step_modeimpute()
    Condition
      Error:
      ! `step_modeimpute()` was deprecated in recipes 0.1.16 and is now defunct.
      i Please use `step_impute_mode()` instead.

