# Deprecation error

    Code
      recipe(~., data = mtcars) %>% step_medianimpute()
    Condition
      Error:
      ! `step_medianimpute()` was deprecated in recipes 0.1.16 and is now defunct.
      i Please use `step_impute_median()` instead.

