# extract_fit_time() works

    Code
      extract_fit_time(rec)
    Condition
      Error in `extract_fit_time()`:
      ! This recipe was created before `recipes::extract_fit_time()` was added. Fit time cannot be extracted.

