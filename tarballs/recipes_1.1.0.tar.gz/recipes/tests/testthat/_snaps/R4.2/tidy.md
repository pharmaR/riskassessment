# bag args

    Code
      tidy(single_step)
    Condition
      Error in `tidy()`:
      ! No `tidy` method for a step with classes: step_notidy, step

---

    Code
      tidy(single_check)
    Condition
      Error in `tidy()`:
      ! No `tidy` method for a check with classes: check_notidy, check

