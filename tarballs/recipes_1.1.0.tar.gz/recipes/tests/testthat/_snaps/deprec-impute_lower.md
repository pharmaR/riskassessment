# Deprecation error

    Code
      recipe(~., data = mtcars) %>% step_lowerimpute()
    Condition
      Error:
      ! `step_lowerimpute()` was deprecated in recipes 0.1.16 and is now defunct.
      i Please use `step_impute_lower()` instead.

