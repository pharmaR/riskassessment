# errors out if not passed a terms object

    Code
      delete_response(1)
    Condition
      Error in `delete_response()`:
      ! `terms` must be a <terms>, not the number 1.

