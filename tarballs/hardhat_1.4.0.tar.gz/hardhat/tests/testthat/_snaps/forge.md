# `run_forge()` throws an informative default error

    Code
      run_forge(1)
    Condition
      Error in `run_forge()`:
      ! No `run_forge()` method provided for an object of type <numeric>.

