expect_matrix <- function(x) {
  expect_true(inherits(x, "matrix"))
}
