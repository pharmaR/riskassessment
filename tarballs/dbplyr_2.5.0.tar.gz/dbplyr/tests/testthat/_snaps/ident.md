# can format ident

    Code
      ident()
    Output
      <IDENT> [empty]

