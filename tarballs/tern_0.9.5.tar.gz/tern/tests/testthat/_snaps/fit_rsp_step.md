# fit_rsp_step works as expected with default options

    Code
      res
    Output
      [1] 11

---

    Code
      res
    Output
       [1] "Percentile Center" "Percentile Lower"  "Percentile Upper" 
       [4] "Interval Center"   "Interval Lower"    "Interval Upper"   
       [7] "n"                 "logor"             "se"               
      [10] "ci_lower"          "ci_upper"         

# fit_rsp_step works as expected with global model fit

    Code
      res
    Output
      [1] 8

---

    Code
      res
    Output
      [1] "Interval Center" "Interval Lower"  "Interval Upper"  "n"              
      [5] "logor"           "se"              "ci_lower"        "ci_upper"       

# fit_rsp_step works as expected with strata

    Code
      res
    Output
      [1] 11

---

    Code
      res
    Output
       [1] "Percentile Center" "Percentile Lower"  "Percentile Upper" 
       [4] "Interval Center"   "Interval Lower"    "Interval Upper"   
       [7] "n"                 "logor"             "se"               
      [10] "ci_lower"          "ci_upper"         

