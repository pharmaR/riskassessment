# control_coxph works with customized parameters

    Code
      res
    Output
      $pval_method
      [1] "wald"
      
      $ties
      [1] "breslow"
      
      $conf_level
      [1] 0.8
      

# control_surv_time works with customized parameters

    Code
      res
    Output
      $conf_level
      [1] 0.8
      
      $conf_type
      [1] "log-log"
      
      $quantiles
      [1] 0.3 0.8
      

# control_surv_timepoint works with customized parameters

    Code
      res
    Output
      $conf_level
      [1] 0.8
      
      $conf_type
      [1] "log-log"
      

