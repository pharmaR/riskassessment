# h_pkparam_sort with PARAMCD

    Code
      res
    Output
      [1] "Cmax"       "AUCinf obs" "CL obs"     "Ae"         "Fe"        
      [6] "CLR"        "Rmax"       "Tonset"     "RENALCLD"  

# h_pkparam_sort with out PARAMCD

    Code
      res
    Output
      [1] "Cmax"       "AUCinf obs" "CL obs"     "Ae"         "Fe"        
      [6] "CLR"        "Rmax"       "Tonset"     "RENALCLD"  

