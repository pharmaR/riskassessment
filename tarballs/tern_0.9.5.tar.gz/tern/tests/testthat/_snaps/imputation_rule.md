# imputation_rule works correctly for 1/3 imputation rule

    Code
      result
    Output
      $val
           max 
      92.40745 
      
      $na_str
      [1] "ND"
      

---

    Code
      result
    Output
      $val
      [1] NA
      
      $na_str
      [1] "ND"
      

---

    Code
      result
    Output
      $val
      geom_mean 
       40.22144 
      
      $na_str
      [1] "NE"
      

---

    Code
      result
    Output
      $val
           max 
      99.26841 
      
      $na_str
      [1] "ND"
      

# imputation_rule works correctly for 1/2 imputation rule

    Code
      result
    Output
      $val
           max 
      92.40745 
      
      $na_str
      [1] "NE"
      

---

    Code
      result
    Output
      $val
          mean 
      43.38858 
      
      $na_str
      [1] "NE"
      

---

    Code
      result
    Output
      $val
      geom_mean 
       40.22144 
      
      $na_str
      [1] "NE"
      

---

    Code
      result
    Output
      $val
           max 
      99.26841 
      
      $na_str
      [1] "NE"
      

