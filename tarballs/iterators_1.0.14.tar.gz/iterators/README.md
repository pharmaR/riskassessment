# iterators

[![CRAN](https://www.r-pkg.org/badges/version/iterators)](https://cran.r-project.org/package=iterators)
![Downloads](https://cranlogs.r-pkg.org/badges/iterators)

A support package used by [foreach](https://github.com/RevolutionAnalytics/foreach).


