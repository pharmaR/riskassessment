package org.apache.spark.sql.util

object __THIS_IS_THE_ROAD_TO_CLOWNTOWN__ArrowUtils {
  // TODO:
  // This is defeating encapsulation and should be avoided if possible.
  //  Sorry, I'm a clown.
  val rootAllocator = org.apache.spark.sql.util.ArrowUtils.rootAllocator
  val toArrowSchema = org.apache.spark.sql.util.ArrowUtils.toArrowSchema(_,_)
}
