# ggplot2.utils 0.3.2

* Replaced dependency on `GGally` with `ggstats` where the original functions are actually from. This also avoids the corresponding overwrite messages coming from `GGally` when loading this package.

# ggplot2.utils 0.3.0

* Added `geom_km` and `geom_km_ticks` (and corresponding `ggproto` and statistics layer functions) for Kaplan-Meier lines and ticks additions to plots, respectively.

# ggplot2.utils 0.2.1

* First publication and CRAN release.

# ggplot2.utils 0.1.5

* Removed dependency on deprecated package `test.nest`.

# ggplot2.utils 0.1.3

* Updated `LICENCE` and `README` with new package references.
* Remove cherry-picked code and instead just import and export the relevant functions.

# ggplot2.utils 0.1.2

* Improved internal code style and removed unnecessary functions imports. 

# ggplot2.utils 0.1.1

* Added `stat_prop()` which is a variation of `stat_count` allowing to compute custom proportions according to the `by` aesthetic defining the denominator.
* Added `stat_n_text()` which adds text indicating the number of y-values for that particular x-value.
* Added `geom_table()`, `geom_table_npc()` which add a textual table directly to the ggplot.

# ggplot2.utils 0.1.0

* Started the package.
