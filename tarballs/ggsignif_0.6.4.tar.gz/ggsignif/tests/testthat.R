library(testthat)
library(ggsignif)
library(ggplot2)

test_check("ggsignif")
