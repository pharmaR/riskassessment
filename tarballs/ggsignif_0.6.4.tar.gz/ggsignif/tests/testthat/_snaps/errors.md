# should not work

    Can only handle data with groups that are plotted on the x-axis

---

    Can only handle data with groups that are plotted on the x-axis

---

    object 'airquality_trimmed' not found

---

    Manual mode only works if with 'annotations' is provided in mapping

---

    If manual mode is selected you need to provide the data and mapping parameters

---

    Can only handle data with groups that are plotted on the x-axis

---

    Manual mode only works if with 'annotations' is provided in mapping

---

    Manual mode only works if with 'annotations' is provided in mapping

