# the plotting works - strict test

    Code
      pb$data
    Output
      [[1]]
          fill     x y PANEL group flipped_aes ymin ymax xmin xmax colour size
      1 grey80 0.875 3     1     1       FALSE    0    3 0.75 1.00     NA  0.5
      2 grey20 1.125 5     1     3       FALSE    0    5 1.00 1.25     NA  0.5
      3 grey80 1.875 7     1     2       FALSE    0    7 1.75 2.00     NA  0.5
      4 grey20 2.125 8     1     4       FALSE    0    8 2.00 2.25     NA  0.5
        linetype alpha
      1        1    NA
      2        1    NA
      3        1    NA
      4        1    NA
      
      [[2]]
            x  xend   y yend annotation PANEL group shape colour textsize angle hjust
      1 0.875 1.125 5.8  5.8        ***     1     1    19  black     3.88     0   0.5
      2 1.875 2.125 8.5  8.5         NS     1     2    19  black     3.88     0   0.5
        vjust alpha family fontface lineheight linetype size
      1     0    NA               1        1.2        1  0.5
      2     0    NA               1        1.2        1  0.5
      
      [[3]]
        x xend     y  yend annotation   group flipped_aes PANEL shape colour textsize
      1 1    1 9.575 9.575        *** S1-S2-1       FALSE     1    19  black     3.88
      2 1    2 9.575 9.575        *** S1-S2-1       FALSE     1    19  black     3.88
      3 2    2 9.575 9.575        *** S1-S2-1       FALSE     1    19  black     3.88
        angle hjust vjust alpha family fontface lineheight linetype size
      1     0   0.5     0    NA               1        1.2        1  0.5
      2     0   0.5     0    NA               1        1.2        1  0.5
      3     0   0.5     0    NA               1        1.2        1  0.5
      

