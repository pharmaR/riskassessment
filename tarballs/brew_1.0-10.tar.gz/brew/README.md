# brew
Brew - R templating system - [https://CRAN.R-project.org/package=brew](https://CRAN.R-project.org/package=brew)

brew provides a templating system for text reporting. The syntax is similar to PHP, Java Server Pages, Ruby’s erb module, and Python’s psp module
