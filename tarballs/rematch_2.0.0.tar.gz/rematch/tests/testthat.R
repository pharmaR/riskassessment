
if (require(testthat)) {
  library(rematch)
  test_check("rematch")
}
