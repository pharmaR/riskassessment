# loggerr_out

    Code
      logger_out(bar, "updated")
    Output
      2021-06-10T13:51:05+00:00 id 13/113 updated

