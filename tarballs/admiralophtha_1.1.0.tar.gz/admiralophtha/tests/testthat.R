library(testthat)
library(admiralophtha)

test_check("admiralophtha")
