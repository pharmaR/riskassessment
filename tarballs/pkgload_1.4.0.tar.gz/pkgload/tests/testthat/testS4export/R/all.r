setClass("foo")
setClass('class_to_export', contains = "foo")
