#' Topic
#'
#' This macro is \unknown{}. This one is \known{}.
testUnknownMacro <- function() {}
