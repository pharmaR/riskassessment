#' Topic
#'
#' This is a foreign macro \mjeqn{success}{success}.
#' @import mathjaxr
macro_downstream <- function() NULL
