
if (require(testthat)) {
  library(rematch2)
  test_check("rematch2")
}
