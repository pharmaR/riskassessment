# testing for lint
a = 1
b <<- 1
d <<- 2
print(b)
