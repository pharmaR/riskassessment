print(environment())
