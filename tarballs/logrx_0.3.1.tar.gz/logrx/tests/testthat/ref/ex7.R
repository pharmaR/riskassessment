# testing for lint
library(dplyr)

print('test')

library(purrr)

d <<- 2
