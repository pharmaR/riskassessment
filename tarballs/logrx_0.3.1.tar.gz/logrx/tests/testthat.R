library(testthat)
library(logrx)

test_check("logrx")
