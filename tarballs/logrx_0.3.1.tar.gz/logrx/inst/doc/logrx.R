## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, echo = FALSE------------------------------------------------------
library(logrx)

## ----axecute, eval = FALSE----------------------------------------------------
#  axecute("my_script.R")

