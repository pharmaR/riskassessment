globalVariables(c(
   "lang",
   "r_version",
   "."
))
