frobnorm <- function(x,y=0,...) {
    sum((x-y)^2)^.5
}
