# pharmaRTF 0.1.4

No functionality changes. Bug fix for tibble 3.1.0 update identified in https://github.com/atorus-research/pharmaRTF/issues/6

# pharmaRTF 0.1.3

No functionality changes. Increment version number with updates for development version of R.

# pharmaRTF 0.1.2

No functionality changes. Increment version with new release of Huxtable

# pharmaRTF 0.1.1

### API Changes
This version is primarily used to adjust some internal functions to be
compatilbe with huxtable 5.0. No major changes to user facing functionailty was made.
Huxtable is now a hard dependancy on pharmaRTF.

### Enhansements
The `header_row` attribute can now be set to 0 to print an `rtf_doc` with no headers. If the 'header_row' attribute is set to 
0, only the titles and footnotes are repeated 
