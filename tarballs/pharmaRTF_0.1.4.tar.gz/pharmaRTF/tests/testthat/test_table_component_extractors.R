context("table_component_extractors")

test_that("The tests for these functions were done in test_rtf-code-generators", {
  expect_true(TRUE)
})
