library(testthat)
library(pharmaRTF)
library(assertthat)
library(huxtable)

test_check("pharmaRTF")
