library(testthat)
library(jose)

test_check("jose")
