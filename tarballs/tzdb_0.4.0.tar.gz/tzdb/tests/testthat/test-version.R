test_that("version is correct", {
  expect_identical(tzdb_version(), "2023c")
})
