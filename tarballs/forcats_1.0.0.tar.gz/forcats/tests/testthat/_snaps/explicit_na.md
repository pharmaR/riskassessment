# fct_explicit_na is deprecated

    Code
      . <- fct_explicit_na(factor())
    Condition
      Warning:
      `fct_explicit_na()` was deprecated in forcats 1.0.0.
      i Please use `fct_na_value_to_level()` instead.

