# request_develop() errors for unrecognized parameters

    These parameters are unknown:
    x 'b'
    x 'c'
    i API endpoint: 'some.api.endpoint'

# request_develop() errors if required parameter is missing

    These parameters are missing:
    x 'a'
    i API endpoint: 'some.api.endpoint'

