library(testthat)
library(ids)

test_check("ids")
