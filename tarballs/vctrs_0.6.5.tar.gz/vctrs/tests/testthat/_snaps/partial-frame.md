# has ok print method

    Code
      pf
    Output
      partial_frame<
        x: integer {partial}
        y: double
      >

