# factor/character coercions are symmetric and unchanging

    Code
      print(mat)
    Output
                ordered<>   factor<>    character  
      ordered<> "ordered<>" NA          "character"
      factor<>  NA          "factor<>"  "character"
      character "character" "character" "character"

