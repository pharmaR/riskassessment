# `crs` attributes of `sfc` vectors must be the same

    Code
      vctrs::vec_c(x, y)
    Condition
      Error:
      ! arguments have different crs

