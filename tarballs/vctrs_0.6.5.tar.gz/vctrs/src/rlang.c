// This is an include point for the implementations of the rlang
// library. It should be included in a single and separate compilation
// unit.

#include "rlang/rlang.c"
