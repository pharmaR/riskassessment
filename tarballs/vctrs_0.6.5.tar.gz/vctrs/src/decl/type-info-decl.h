static
enum vctrs_type vec_base_typeof(r_obj* x, bool proxied);
