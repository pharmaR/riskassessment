library(testthat)
library(testTestWithDepends)

test_check("testTestWithDepends")
