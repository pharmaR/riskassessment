Table: Caption `base::t`

| `base::t` | xx |
|----------:|:---|
| `base::t` | yy |

