# S4 character class (tidyverse/tibble#1367)

    Code
      pillar(DBI::SQL("x"))
    Output
      <pillar>
      <SQL>
      x    

