# throws error if can't find tests/testthat

    Code
      test_path("empty")
    Condition
      Error in `test_path()`:
      ! Can't find 'tests/testthat'.

