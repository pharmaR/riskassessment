# snapshot

    Code
      1:10
    Output
       [1]  1  2  3  4  5  6  7  8  9 10

