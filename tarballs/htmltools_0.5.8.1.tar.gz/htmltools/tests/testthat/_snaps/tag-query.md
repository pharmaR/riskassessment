# tagQuery() print method displays custom output for selected tags

    `$allTags()`:
    <div>
      <span></span>
    </div>
    
    `$selectedTags()`: `$allTags()`

---

    `$allTags()`:
    <div>
      <span></span>
    </div>
    
    `$selectedTags()`:
    [[1]]
    <span></span>
    

---

    `$allTags()`:
    <div>
      <span></span>
    </div>
    
    `$selectedTags()`: (Empty selection)

