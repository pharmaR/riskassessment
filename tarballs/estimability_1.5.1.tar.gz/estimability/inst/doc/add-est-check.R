## ---- echo = FALSE, results = "hide", message = FALSE-------------------------
require("estimability")
knitr::opts_chunk$set(fig.width = 4.5, class.output = "ro")

