library(testthat)
library(rstatix)

test_check("rstatix")
