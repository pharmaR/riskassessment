library(testthat)
library(metacore)

test_check("metacore")
